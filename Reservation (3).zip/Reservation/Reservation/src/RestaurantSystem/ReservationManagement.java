package RestaurantSystem;
	 


import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;

import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import Booknow.Book;


public class ReservationManagement {
	
	
	private static final String request = null;
	private JFrame frame;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel1;
	private JLabel lblNewLabel11;
	private JPanel panel;
	
	private JTextField txtFood;
	private JTextField txtQuantity;
	private JComboBox comboBox_6_2;
	private JTextField textField;
	private JTextField textField1;
	
	private JLabel lblNewLabel2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReservationManagement window = new ReservationManagement();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	

	/**
	 * Create the application.
	 */
	public ReservationManagement() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.PINK);
		frame.setBounds(100, 100, 1426, 870);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		Component horizontalGlue = Box.createHorizontalGlue();
		horizontalGlue.setBounds(38, 106, 1, 1);
		horizontalGlue.setBackground(Color.RED);
		frame.getContentPane().add(horizontalGlue);
		
		lblNewLabel = new JLabel("RESERVATION");
		
		lblNewLabel.setBounds(529, 13, 426, 116);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 39));
		lblNewLabel.setForeground(Color.MAGENTA);
		frame.getContentPane().add(lblNewLabel);
		
		panel = new JPanel();
		panel.setBounds(110, 100, 1200, 600);
		panel.setBorder(new LineBorder(Color.BLUE, 5, true));
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		comboBox_6_2 = new JComboBox();
		comboBox_6_2.setModel(new DefaultComboBoxModel(new String[] {"Hall Araliya", "Hall Gadiniya", "Swimming Pool", "Table 1", "Table VIP", "Table 2"}));
		comboBox_6_2.setBounds(100, 100, 1000, 50);
		panel.add(comboBox_6_2);
		
		
		 lblNewLabel1 = new JLabel("CHECK IN");
		
		lblNewLabel1.setBounds(100, 200, 426, 116);
		lblNewLabel1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel1.setForeground(Color.MAGENTA);
		panel.add(lblNewLabel1);
		
		textField = new JTextField();
		textField.setText("CheckIN");
		textField.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		textField.setColumns(10);
		textField.setBackground(Color.WHITE);
		textField.setBounds(240, 245, 152, 31);
		panel.add(textField);
		
		
		lblNewLabel11 = new JLabel("CHECK OUT");
		
		lblNewLabel11.setBounds(800, 200, 426, 116);
		lblNewLabel11.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel11.setForeground(Color.MAGENTA);
		panel.add(lblNewLabel11);
		
		
		textField1 = new JTextField();
		textField1.setText("CheckOut");
		textField1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		textField1.setColumns(10);
		textField1.setBackground(Color.WHITE);
		textField1.setBounds(950, 245, 152, 31);
		panel.add(textField1);
		
		
		JButton btnNewButton = new JButton("BOOK NOW");
		btnNewButton.addActionListener(new ActionListener() {
			
					
			@Override
			public void actionPerformed(ActionEvent e) {
				
				 Book newBook=new Book();
					Book.main(null);
				// TODO Auto-generated method stub
				
			}
		});
		
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnNewButton.setBounds(650, 763, 200, 47);
		frame.getContentPane().add(btnNewButton);
		    
		
		
	}
}

	
	


	
	
