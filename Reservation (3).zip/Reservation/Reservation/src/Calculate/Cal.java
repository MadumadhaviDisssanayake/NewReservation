package Calculate;

import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import Booknow.Book;
import UpdateBooking.Update;
import UpdateBooking.dbconnector;

public class Cal {
	
	
	private JFrame frame;
	private JLabel lblNewLabel;
	private JPanel panel;
	private JPanel panel1;
	private JPanel panel11;
	private JPanel panel2;
	private JPanel panel3;
	private JPanel panel4;
	private JPanel panel5;
	private JTextField txtReservation;
	
	private JTextField txtHall;
	private JTextField txtQuantity;
	private JComboBox comboBox_6_2;
	private JComboBox comboBox2;
	private JComboBox comboBox3;
	private JComboBox comboBox4;
	private JComboBox comboBox5;
	private JComboBox comboBox6;
	private Checkbox checkbox_1;
	
	private JLabel lblNewLabel2;
	private JLabel lblNewLabel3;
	private JLabel lblNewLabel4;
	private JLabel lblNewLabel5;
	private JLabel lblNewLabel6;
	
	private JLabel lblNewLabel7;
	private JLabel lblNewLabel8;
	private JLabel lblNewLabel9;
	private JLabel lblNewLabel10;
	private JLabel lblNewLabel11;
	private JLabel lblNewLabel12;
	private JLabel lblNewLabel13;
	private JLabel lblNewLabel14;
	private JLabel lblNewLabel15;
	private JLabel lblNewLabel16;
	private JLabel lblNewLabel17;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cal window = new Cal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	
	public Cal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		frame.setBounds(100, 100, 1426, 870);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		Component horizontalGlue = Box.createHorizontalGlue();
		horizontalGlue.setBounds(38, 106, 1, 1);
		horizontalGlue.setBackground(Color.RED);
		frame.getContentPane().add(horizontalGlue);
		
		panel = new JPanel();
		panel.setBounds(30, 100, 1300, 50);
		panel.setBorder(new LineBorder(Color.BLACK, 5, true));
		frame.add(panel);
		panel.setLayout(null);
		
		lblNewLabel = new JLabel("Pool");
		
		lblNewLabel.setBounds(30, 15 , 100, 11);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel.setForeground(Color.RED);
		panel.add(lblNewLabel);
		
		
		lblNewLabel2 = new JLabel("POOL ONLY");
		
		lblNewLabel2.setBounds(30, 170 , 150, 11);
		lblNewLabel2.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel2.setForeground(Color.RED);
		frame.add(lblNewLabel2);
		
		
		lblNewLabel3 = new JLabel("Occupancy");
		
		lblNewLabel3.setBounds(30, 200 , 150, 20);
		lblNewLabel3.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel3.setForeground(Color.RED);
		frame.add(lblNewLabel3);
		
		comboBox3 = new JComboBox();
		comboBox3.setModel(new DefaultComboBoxModel(new String[] {"Single", "Double", "Family"}));
		comboBox3.setBounds(30, 230, 150, 30);
		frame.add(comboBox3);
		
		
		
		lblNewLabel4 = new JLabel("Children(2-12Y)");
		
		lblNewLabel4.setBounds(30, 270 , 150, 20);
		lblNewLabel4.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel4.setForeground(Color.RED);
		frame.add(lblNewLabel4);
		
		comboBox4 = new JComboBox();
		comboBox4.setModel(new DefaultComboBoxModel(new String[] {"0", "1", "2","3","4","5"}));
		comboBox4.setBounds(30, 290, 150, 30);
		frame.add(comboBox4);
		
		
		lblNewLabel5 = new JLabel("Adults");
		
		lblNewLabel5.setBounds(1000, 200 , 150, 20);
		lblNewLabel5.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel5.setForeground(Color.RED);
		frame.add(lblNewLabel5);
		
		comboBox5 = new JComboBox();
		comboBox5.setModel(new DefaultComboBoxModel(new String[] {"0", "1", "2","3","4","5"}));
		comboBox5.setBounds(1000, 230, 150, 30);
		frame.add(comboBox5);
		
		
		
		
		lblNewLabel6= new JLabel("Infants(0-2Y)");
		
		lblNewLabel6.setBounds(1000, 270 , 150, 20);
		lblNewLabel6.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel6.setForeground(Color.RED);
		frame.add(lblNewLabel6);
		
		comboBox6 = new JComboBox();
		comboBox6.setModel(new DefaultComboBoxModel(new String[] {"0", "1", "2","3","4","5"}));
		comboBox6.setBounds(1000, 290, 150, 30);
		frame.add(comboBox6);
		
		panel = new JPanel();
		panel.setBounds(30, 350, 1350, 400);
		panel.setBorder(new LineBorder(Color.CYAN, 5, true));
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		lblNewLabel7= new JLabel("Calculate Rates");
		
		lblNewLabel7.setBounds(529, 13 , 426, 116);
		lblNewLabel7.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel7.setForeground(Color.RED);
		panel.add(lblNewLabel7);
		
		
		panel1 = new JPanel();
		panel1.setBounds(30, 100, 1300, 36);
		panel1.setBorder(new LineBorder(Color.BLACK, 5, true));
		panel.add(panel1);
		panel1.setLayout(null);
		
		lblNewLabel8= new JLabel(" Rates");
		
		lblNewLabel8.setBounds(30, 15 , 200, 10);
		lblNewLabel8.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel8.setForeground(Color.BLACK);
		panel1.add(lblNewLabel8);
		
		panel11 = new JPanel();
		panel11.setBounds(30, 140, 1300, 36);
		panel11.setBorder(new LineBorder(Color.BLACK, 5, true));
		panel.add(panel11);
		panel11.setLayout(null);
		
		lblNewLabel9= new JLabel(" Pool Rate Only");
		
		lblNewLabel9.setBounds(30, 10 , 200, 14);
		lblNewLabel9.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel9.setForeground(Color.BLACK);
		panel11.add(lblNewLabel9);
		
		
		panel2= new JPanel();
		panel2.setBounds(30, 180, 1300, 36);
		panel2.setBorder(new LineBorder(Color.BLACK, 5, true));
		panel.add(panel2);
		panel2.setLayout(null);
		
		lblNewLabel10= new JLabel(" Pool ");
		
		lblNewLabel10.setBounds(30, 10 , 200, 14);
		lblNewLabel10.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel10.setForeground(Color.BLACK);
		panel2.add(lblNewLabel10);
		
		lblNewLabel11= new JLabel(" USD 102 ");
		
		lblNewLabel11.setBounds(1000, 10 , 700, 14);
		lblNewLabel11.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel11.setForeground(Color.BLACK);
		panel2.add(lblNewLabel11);
		
		
		panel3= new JPanel();
		panel3.setBounds(30, 220, 1300, 36);
		panel3.setBorder(new LineBorder(Color.BLACK, 5, true));
		panel.add(panel3);
		panel3.setLayout(null);
		lblNewLabel12= new JLabel("  Total Pool Rate ");
		lblNewLabel12.setBounds(30, 10 , 200, 14);
		lblNewLabel12.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel12.setForeground(Color.BLACK);
		panel3.add(lblNewLabel12);
		
		lblNewLabel13= new JLabel(" USD 102 ");
		
		lblNewLabel13.setBounds(1000, 10 , 700, 14);
		lblNewLabel13.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel13.setForeground(Color.BLACK);
		panel3.add(lblNewLabel13);
		
		
		
		panel4= new JPanel();
		panel4.setBounds(30, 260, 1300, 36);
		panel4.setBorder(new LineBorder(Color.BLACK, 5, true));
		panel.add(panel4);
		panel4.setLayout(null);
		
		lblNewLabel14= new JLabel("  Tax ");
		lblNewLabel14.setBounds(30, 10 , 200, 14);
		lblNewLabel14.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel14.setForeground(Color.BLACK);
		panel4.add(lblNewLabel14);
		
		lblNewLabel15= new JLabel(" USD 11");
		
		lblNewLabel15.setBounds(1000, 10 , 700, 14);
		lblNewLabel15.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel15.setForeground(Color.BLACK);
		panel4.add(lblNewLabel15);
		
		
		
		
		
		panel5= new JPanel();
		panel5.setBounds(30, 300, 1300, 36);
		panel5.setBorder(new LineBorder(Color.BLACK, 5, true));
		panel.add(panel5);
		panel5.setLayout(null);
		
		
		lblNewLabel16= new JLabel("  Total ");
		lblNewLabel16.setBounds(30, 10 , 200, 14);
		lblNewLabel16.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel16.setForeground(Color.BLACK);
		panel5.add(lblNewLabel16);
		
		lblNewLabel17= new JLabel(" USD 113");
		
		lblNewLabel17.setBounds(1000, 10 , 700, 14);
		lblNewLabel17.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel17.setForeground(Color.BLACK);
		panel5.add(lblNewLabel17);
		

		
		JButton btnNewButton = new JButton("PROCEED");
		btnNewButton.addActionListener(new ActionListener() {
			//public void actionPerformed1(ActionEvent arg0) {
			//public void actionPerformed(ActionEvent e) {
				
				 
			//}

//			@Override
			public void actionPerformed(ActionEvent arg0) {
				dbconnector con=new dbconnector();
				
				try {
					boolean status;
					status = con.createbooking((String)comboBox5.getSelectedItem(), (String)comboBox4.getSelectedItem(), 113.5);
					
					JOptionPane.showMessageDialog(null, "Item Added");
				}
				catch(Exception ex) {
					System.out.println(ex);
					System.out.println("EEE");
					JOptionPane.showMessageDialog(null, "Item not found");
				}finally {}
			
	
				Update newUpdate=new Update();
				Update.main(null);
			
//				// TODO Auto-generated method stub
//				
		}
		});
		
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnNewButton.setBounds(500, 763, 400, 47);
		frame.getContentPane().add(btnNewButton);
		
		
	}
}
