package UpdateBooking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class dbconnector {
	private static String url="jdbc:mysql://localhost:3306/restaurent?\" + \"autoReconnect=true&useSSL=false";
	private  static String  username="madu";
	private static String password="madu";
	private static Connection con;
	private static boolean isSuccess;
	private static Statement stmt= null;
	private static ResultSet rs= null;
	
	public static Connection getconnection() {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			con=DriverManager.getConnection(url,username,password);	
					
		}
		catch(Exception e) {
			System.out.println("Database connection is not successfull");
		}
	
		return con;
		
	}
	
	
	public boolean createbooking(String adlt, String chldrn, double ttl) {
		
		try {
			con= getconnection();
			stmt= con.createStatement();
			String sql="insert into reservation (adult, children, total) values ('"+adlt+"','"+chldrn+"','"+ttl+"')";
			 int rs= stmt.executeUpdate(sql);
			 
			 
			 if(rs>0) {
				 isSuccess=true;
				 System.out.println(isSuccess);
			 }
			 
			 else {
				 isSuccess=false;
				 System.out.println(isSuccess);
			 }
			
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
		return isSuccess;
	}
	
	
	
	public boolean deletebooking(int id) {
		
		try {
			 
			con= getconnection();
			stmt= con.createStatement();
			String sql ="delete from reservation where reservationID='"+id+"'";
			int r=stmt.executeUpdate(sql);
			
			
			if(r>0) {
				isSuccess=true;
			}
			else {
				isSuccess=false;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return isSuccess;
	}


}
